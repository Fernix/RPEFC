/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebaconstruccion.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import pruebaconstruccion.logica.Equipo;

/**
 *
 * @author ferc
 */
public class EquipoDao extends GenericDao<Equipo> {

  @Override
  public void guardarEquipo(Equipo equipo) {
   
  }

  @Override
  public Equipo consultarInventario(int id) {
    
     Connection miConexion = this.conectar();
		
		PreparedStatement stp = null;
		try {
			stp = miConexion.prepareStatement("SELECT * FROM equipo WHERE idequipo = ? ");
                        stp.setInt(1, id);
			ResultSet resultadoQuery = stp.executeQuery();
			resultadoQuery.next(); 
			int idEquipo = resultadoQuery.getInt("idequipo");
			int numeroSerie = resultadoQuery.getInt("numero_serie");
			boolean disponibilidad = resultadoQuery.getBoolean("disponibilidad");
                        
                        Equipo nz = new Equipo(idEquipo, numeroSerie, disponibilidad);
                        System.out.println("pasó");
			return nz;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
                        System.out.println("Holi");
                        System.out.println(e);
			e.printStackTrace();
		} finally {
			try {
				miConexion.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			
		
		return null;
  }


  
}
