package pruebaconstruccion.db;

public class CredencialesBd {
	
	static public final String usuario = "admonpruebac";
	static public final String password = "IriNando2403.";
	static public final String baseDatos = "prueba_construccion";
	static public final String host = "localhost";

}
